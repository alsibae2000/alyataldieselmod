/**
 * Home — آليات الديزل
 * الصفحة الرئيسية الكاملة
 * تجمع جميع الأقسام في تسلسل منطقي
 */
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import ServicesSection from "@/components/ServicesSection";
import ProductsSection from "@/components/ProductsSection";
import BrandsSection from "@/components/BrandsSection";
import MapSection from "@/components/MapSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";

export default function Home() {
  return (
    <div className="min-h-screen bg-[oklch(0.10_0.005_260)]" dir="rtl">
      <Navbar />
      <HeroSection />
      <MapSection />
      <AboutSection />
      <ServicesSection />
      <ProductsSection />
      <BrandsSection />
      <ContactSection />
      <Footer />
      <WhatsAppFloat />
    </div>
  );
}
